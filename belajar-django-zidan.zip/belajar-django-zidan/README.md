# Repository Web Hasil Belajar Django 2.2

Cara melihat website ini adalah dengan cara sebagai berikut:

1. Pasang `python3`
2. Pasang `django >= 2.2` (misal lewat `pip`)
3. Unduh repositori ini.
4. Ekstrak zip (kalau unduh lewat zip)
5. Buka direktori hasil ekstraksi lewat terminal
6. Jalankan perintah `python manage.py runserver`
7. Buka peramban, masukkan alamat http://localhost:8000/polls

Mohon bimbingannya untuk saran perbaikan.

Terima kasih.